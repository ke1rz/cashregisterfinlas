/*
import java.util.*;

public class Main {
    static Scanner mark = new Scanner(System.in);
    static int[] menuNumbers = {1, 2, 3, 4, 5, 6};
    static String[] menuProducts = {"Chicken Joy", "Jolly Spaghetti", "Burger Steak", "Yumburger", "Fries", "Coke Float"};
    static double[] menuPrices = {99.00, 75.00, 90.00, 55.00, 45.00, 39.00};

    public static void displayMenu() {
        System.out.println("\nJollibee Menu:");
        for (int i = 0; i < menuProducts.length; i++) {
            System.out.println(menuNumbers[i] + ". " + menuProducts[i] + " - PHP " + menuPrices[i]);
        }
    }

    public static void addItemToCart(ArrayList<String> cartProducts, ArrayList<Double> cartProductPrices, ArrayList<Double> cartTotalPrices, ArrayList<Integer> cartQuantities) {
        System.out.print("Enter menu number: ");
        int menuChoice = mark.nextInt();
        mark.nextLine();

        if (menuChoice >= 1 && menuChoice <= menuProducts.length) {
            String itemName = menuProducts[menuChoice - 1];
            double itemPrice = menuPrices[menuChoice - 1];
            System.out.print("Enter quantity: ");
            int quantity = mark.nextInt();
            mark.nextLine();

            cartProducts.add(itemName);
            cartProductPrices.add(itemPrice);
            cartQuantities.add(quantity);
            cartTotalPrices.add(itemPrice * quantity);

            System.out.println(itemName + " added to cart!");
        } else {
            System.out.println("Invalid menu choice.");
        }
    }

    public static void viewCart(ArrayList<String> cartProducts, ArrayList<Double> cartProductPrices, ArrayList<Double> cartTotalPrices, ArrayList<Integer> cartQuantities) {
        System.out.println("\nCurrent Cart:");
        if (cartProducts.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }
        for (int i = 0; i < cartProducts.size(); i++) {
            System.out.println(cartProducts.get(i) + " | Qty: " + cartQuantities.get(i) + " | Price: PHP " + cartProductPrices.get(i) + " | Total: PHP " + cartTotalPrices.get(i));
        }
    }

    public static double checkout(ArrayList<String> cartProducts, ArrayList<Double> cartTotalPrices) {
        double total = 0;
        System.out.println("\nFinal Receipt:");
        for (int i = 0; i < cartProducts.size(); i++) {
            System.out.println(cartProducts.get(i) + " | Total: PHP " + cartTotalPrices.get(i));
            total += cartTotalPrices.get(i);
        }
        System.out.println("Total Amount: PHP " + total);
        return total;
    }

    public static void processPayment(double total) {
        double payment;
        do {
            System.out.print("Enter payment amount: PHP ");
            payment = mark.nextDouble();
            mark.nextLine();
            if (payment < total) {
                System.out.println("Insufficient amount. Please enter at least PHP " + total);
            }
        } while (payment < total);

        double change = payment - total;
        System.out.println("Payment accepted! Your change: PHP " + change);
        System.out.println("Checkout complete! Enjoy your meal!");
    }

    public static void main(String[] args) {
        boolean anotherTransaction = true;

        while (anotherTransaction) {
            ArrayList<String> cartProducts = new ArrayList<>();
            ArrayList<Double> cartProductPrices = new ArrayList<>();
            ArrayList<Double> cartTotalPrices = new ArrayList<>();
            ArrayList<Integer> cartQuantities = new ArrayList<>();

            while (true) {
                displayMenu();
                System.out.println("\n1. Order  2. View Cart  3. Checkout  4. Exit");
                System.out.print("Choose an option: ");
                int choice = mark.nextInt();
                mark.nextLine();

                switch (choice) {
                    case 1:
                        addItemToCart(cartProducts, cartProductPrices, cartTotalPrices, cartQuantities);
                        break;
                    case 2:
                        viewCart(cartProducts, cartProductPrices, cartTotalPrices, cartQuantities);
                        break;
                    case 3:
                        if (cartProducts.isEmpty()) {
                            System.out.println("Cart is empty. Add items before checkout.");
                        } else {
                            double total = checkout(cartProducts, cartTotalPrices);
                            processPayment(total);
                            break;
                        }
                        break;
                    case 4:
                        System.out.println("Exiting... Thank you!");
                        anotherTransaction = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
                if (choice == 3 || choice == 4) {
                    break;
                }
            }

            if (anotherTransaction) {
                System.out.print("Would you like to perform another transaction? (yes/no): ");
                String response = mark.next().toLowerCase();
                mark.nextLine();
                anotherTransaction = response.equals("yes");
            }
        }
        System.out.println("Thank you for visiting Jollibee!");
        mark.close();
    }
}
*/
