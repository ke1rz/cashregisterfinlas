
/*
import java.util.*;

public class Main {
    public static void main(String[] args) {
        ArrayList<String[]> searchHistory = new ArrayList<>();
        Scanner mark = new Scanner(System.in);
        
        System.out.println("Search Movie");
        System.out.println("MOVIE TITLE");
        System.out.println("DIRECTOR NAME");
        System.out.println("DATE RELEASED");
        

        while (true) {
            System.out.print("Enter a movie title: ");
            String title = mark.nextLine();

            if (title.equalsIgnoreCase("exit")) {
                System.out.println("Goodbye!");
                break;
            }

            System.out.print("Enter the director name: ");
            String director = mark.nextLine();
            
            System.out.print("Date released: ");
            String date = mark.nextLine();

            String[] movie = {title, director, date};
            searchHistory.add(movie);
            
            System.out.println("\nMovie Found:");
            System.out.println("Title: " + title);
            System.out.println("Director: " + director);
            System.out.println("Date: " + date);
            System.out.println("------------------------------------");
            String searchmov = mark.nextLine();

            System.out.println("\nSearch History:");
            for (String[] m : searchHistory) {
                System.out.println("Title: " + m[0]);
                System.out.println("Director: " + m[1]);
                System.out.println("Date: " + m[2]);
                System.out.println("------------------------------------");
            }
        }
    }
}
*/