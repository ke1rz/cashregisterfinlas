/*

import java.util.*;
public class Main {
    public static void display(ArrayList<String> Pname ){
        
        //use functions para malinis ang code
       for (int i = 0; i < Pname.size(); i++){
           System.out.println(Pname.get(i));
       }
    }
    public static void main(String[] args) {
        Scanner mark = new Scanner (System.in);
        ArrayList<String> Pname = new ArrayList<String>();
        
        Pname.add("marky");
        Pname.add("cj");
        Pname.add("sevy");
        Pname.add("rony");
        Pname.add("gab");
        
        display(Pname);
        
        System.out.println("-----------------------------");
        //Pname.set(0, "miko");
        //display(Pname);
        //kapag walang index para hanapin at palitan ang name
        System.out.print("Enter a name to search: ");
        String name = mark.nextLine();
        
        System.out.print("Enter a new name: ");
        String Nname = mark.nextLine();
        
        
        for (int i =0; i<Pname.size(); i++){
            if(Pname.get(i).equals(name)){
                Pname.set(i, Nname);
            }
            
        }
         display(Pname);
        //System.out.println(Pname);
        
        System.out.println("-----------------------------");
        
        System.out.print("Enter a name to remove: ");
        String Rname = mark.nextLine();
        
        
        
        for (int i =0; i<Pname.size(); i++){
            if(Pname.get(i).equals(Rname)){
                Pname.remove(i);
            }
            
        }
        display(Pname);
        
        
        System.out.println("-----------------------------");
        
       
        
        
       
    }
}

*/
