       
/*
Scanner mark = new Scanner(System.in);
        ArrayList<String> Stuname = new ArrayList<String>();
        String choice = "yes";
        
        System.out.println("---------------------------------------");
        System.out.println("            STUDENT REGISTRATION         ");
        System.out.println("1-ADD STUDENT");
        System.out.println("2-EDIT STUDENT NAME");
        System.out.println("3-DISPLAY STUDENT NAME");
        System.out.println("4-REMOVE STUDENT NAME");
        System.out.println("---------------------------------------");
        
        System.out.print("Enter choice: ");
        int option = mark.nextInt();
        mark.nextLine(); 
        
        switch (option) {
            case 1:
                do {
                    System.out.print("Enter student name: ");
                    String pangalan = mark.nextLine();
                    Stuname.add(pangalan); 
                    System.out.print("Do you want to add another student? (yes/no): ");
                    choice = mark.nextLine();
                } while (choice.equals("yes"));
                break;
                
            case 2:
                do {
                    System.out.print("Search Name: ");
                    String Sname = mark.nextLine();
                    System.out.print("Enter new Name: ");
                    String Newname = mark.nextLine();
                    
                    for (int i = 0; i < Stuname.size(); i++) {
                        if (Stuname.get(i).equals(Sname)) {
                            Stuname.set(i, Newname);
                        }
                    }
                    System.out.print("Do you want to edit another student name? (yes/no): ");
                    choice = mark.nextLine();
                } while (choice.equals("yes"));
                break;
                
            case 3:
                display(Stuname);
                break;
                
            case 4:
                System.out.print("Enter student name to remove: ");
                String Rstdname = mark.nextLine();
                
                for (int i = 0; i < Stuname.size(); i++) {
                    if (Stuname.get(i).equals(Rstdname)) {
                        Stuname.remove(i);
                        break; 
                    }
                }
                break;
                
            default:
                System.out.println("Invalid choice! Please enter a valid option.");
                break;
                
        }
        
        
        public static void display(ArrayList<String> Stuname) {
        if (Stuname.isEmpty()) {
            System.out.println("No students registered.");
        } else {
            System.out.println("Registered Students:");
            for (String name : Stuname) {
                System.out.println(name);
            }
        }
    }
*/

